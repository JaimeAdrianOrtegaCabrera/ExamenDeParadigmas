
public class Musica extends DatosDeLasCanciones {
    public void cancion(){
    System.out.println("Esa musica es muy bonita"+limit);
    }
    
}
