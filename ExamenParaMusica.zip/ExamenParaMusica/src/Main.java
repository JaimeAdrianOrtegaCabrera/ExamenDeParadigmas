import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
    int Resultado;
Scanner s= new Scanner(System.in);

DatosDeLasCanciones n=new Musica();
n.NombreCancion();
n.NombreArtista();
n.NombreGenero();
n.NombreAlbum();
n.AñoLanzamiento();
n.NombreDisquera();
    }
  
}
